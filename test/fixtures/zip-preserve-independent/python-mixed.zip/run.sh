#!/bin/sh
printf "hello"
