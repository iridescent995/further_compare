Info-ZIP independently produced
